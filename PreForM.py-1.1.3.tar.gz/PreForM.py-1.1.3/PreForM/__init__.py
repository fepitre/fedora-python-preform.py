"""
PreForM.py, Preprocessor for Fortran poor Men
"""

