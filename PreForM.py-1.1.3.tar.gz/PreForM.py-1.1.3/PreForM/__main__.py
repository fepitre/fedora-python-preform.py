#!/usr/bin/env python
from .PreForM import main
main()
